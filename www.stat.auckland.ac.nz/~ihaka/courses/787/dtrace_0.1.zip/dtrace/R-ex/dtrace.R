### Name: dtrace
### Title: Density Traces
### Aliases: dtrace dtrace.numeric dtrace.list dtrace.formula
### Keywords: distribution smooth

### ** Examples

## The rectangular kernel with bw = 1.
plot(dtrace(0, bw=1, kern="r"),
     main = "Rectangular Kernel (bw = 1)",
     xlab = "This is the output from ``dtrace''")

## Compare this with the density function.
## It's hard to see how bw = 1 here..
plot(density(0, bw=1, kern="r"),
   main = "Rectangular Kernel (bw = 1)",
   xlab = "This is the output from ``density''")

## The Gaussian kernel with sd = 1.
plot(dtrace(0, sd=1, kern="g"),
     main = "Gaussian Kernel (sd = 1)")

## A moving-cell histogram and an equivalent
## fixed-cell histogram.  Note that the fixed-cell
## variant is less stable than it appears.
x <- rnorm(100)
d <- dtrace(x, bw=.5, kern = "r", n=1024)
hist(x, breaks = seq(floor(min(x)), ceiling(max(x)), by = .5),
     prob = TRUE, ylim = d$ylim, border = "gray40",
     main = "Fixed and Moving-Cell Histograms")
plot(d, col = "red", add = TRUE)

## A comparison of rectangular and Gaussian kernels
## with the same bandwidth.
d <- dtrace(list(Rectangular = x,
                       Gaussian = x),
            bw = 1, kern = c("r", "g"))
plot(d, col = c("green4", "red"), lty = 1,
     main = "``Equivalent Bandwidth'' Kernels",
     xlab = "Rectangular and Gaussian, (bw = 1, sd = 0.2887)")

## Simple density estimation.
## Here we are using automatic bandwidth selection.
data(faithful)
d <- dtrace(faithful$eruptions, sd = "sj")
summary(d)
plot(d, xlab = "Eruption Time in Minutes",
     main = "Old Faithful Data")

## A customized plot.  This is just to show how
## to access the underlying density structure.
plot(d$density[[1]], type = "n",
     xlab = "Eruption Time in Minutes",
     ylab = "Density",
     main = "Old Faithful Data")
polygon(d$density[[1]], col = "wheat")

## Estimation and plotting of three densities.
## A demonstration of the formula-based interface.
data(iris)
d <- dtrace(Petal.Width ~ Species, data = iris)
plot(d, lty = 1, col = c("red","green4", "blue"),
     legend = c("Setosa", "Versicolor", "Virginica"),
     main = "The Distribution of Iris Petal Width",
     xlab = "Petal Width (cm)")



