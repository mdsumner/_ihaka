### Name: [.dtrace
### Title: Subsetting of density trace objects
### Aliases: [.dtrace [[.dtrace
### Keywords: distribution smooth

### ** Examples

## Estimation and plotting of three densities.
## A demonstration of the formula-based interface.
data(iris)
d <- dtrace(Petal.Width ~ Species, data = iris)
summary(d[1])
plot(d[[2]], type = "l")



