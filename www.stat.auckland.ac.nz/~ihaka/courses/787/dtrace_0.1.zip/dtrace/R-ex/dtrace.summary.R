### Name: summary.dtrace
### Title: Summaries for dtrace Objects
### Aliases: summary.dtrace print.summary.dtrace
### Keywords: distribution smooth

### ** Examples

## Simple density estimation.
## Here we are using automatic bandwidth selection.
data(faithful)
d <- dtrace(faithful$eruptions, sd = "sj")
plot(d, xlab = paste("Kernel Bandwidth =",
                     signif(summary(d)$bw, 4)),
     main = "Old Faithful Data")



