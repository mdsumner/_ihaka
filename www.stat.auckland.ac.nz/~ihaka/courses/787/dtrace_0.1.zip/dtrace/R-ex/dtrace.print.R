### Name: print.dtrace
### Title: Printing Density Trace Objects
### Aliases: print.dtrace
### Keywords: distribution smooth

### ** Examples

## Simple density estimation.
data(faithful)
d <- print(dtrace(faithful$eruptions, sd = "sj"))



