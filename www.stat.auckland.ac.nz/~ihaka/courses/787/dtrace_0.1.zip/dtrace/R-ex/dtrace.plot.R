### Name: plot.dtrace
### Title: Plot a Density Trace Object
### Aliases: plot.dtrace
### Keywords: hplot distribution smooth

### ** Examples

## Estimation and plotting of three densities.
## A demonstration of the formula-based interface.
data(iris)
d <- dtrace(Petal.Width ~ Species, data = iris)
plot(d, lty = 1, col=c("red","green4", "blue"),
     legend = c("Setosa", "Versicolor", "Virginica"),
     main = "The Distribution of Iris Petal Width",
     xlab = "Petal Width (cm)")



