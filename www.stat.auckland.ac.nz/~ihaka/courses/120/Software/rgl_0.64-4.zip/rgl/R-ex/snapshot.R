###--- >>> `rgl.snapshot' <<<----- export screenshot

	## alias	 help(rgl.snapshot)

##___ Examples ___:


##Don't run: 
##D 
##D #
##D # create animation
##D #
##D 
##D for (i in 1:45) {
##D   rgl.viewpoint(i,20)
##D   print( paste("pic",formatC(i,digits=1,flag="0"),".png",sep="") )
##D   rgl.snapshot(filename)
##D }
##D 



## Keywords: 'dynamic'.


