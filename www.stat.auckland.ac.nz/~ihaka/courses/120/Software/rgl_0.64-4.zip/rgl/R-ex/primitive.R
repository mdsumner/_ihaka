###--- >>> `rgl.primitive' <<<----- add primitive set shape

	## alias	 help(rgl.primitive)
	## alias	 help(rgl.points)
	## alias	 help(rgl.lines)
	## alias	 help(rgl.triangles)
	## alias	 help(rgl.quads)

##___ Examples ___:

rgl.clear()
rgl.points(rnorm(1000),rnorm(1000),rnorm(1000),color=heat.colors(1000),size=2)

## Keywords: 'dynamic'.


