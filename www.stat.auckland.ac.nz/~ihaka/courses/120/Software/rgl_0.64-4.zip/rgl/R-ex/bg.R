###--- >>> `rgl.bg' <<<----- setup Background

	## alias	 help(rgl.bg)

##___ Examples ___:


  # the holo-globe (inspired by star trek):

  rgl.bg(sphere=TRUE, color=c("black","green"), lit=FALSE, back="lines" )

  # an environmental sphere with a nice texture.

  rgl.bg(sphere=TRUE, texture= system.file("textures/sunsleep.png",package="rgl"), back="filled" )

## Keywords: 'dynamic'.


