###--- >>> `rgl.surface' <<<----- add height-field surface shape

	## alias	 help(rgl.surface)

##___ Examples ___:


#
# volcano example taken from "persp"
#

data(volcano)

y <- 2 * volcano        # Exaggerate the relief

x <- 10 * (1:nrow(y))   # 10 meter spacing (S to N)
z <- 10 * (1:ncol(y))   # 10 meter spacing (E to W)

ylim <- range(y)
ylen <- ylim[2] - ylim[1] + 1

colorlut <- rainbow(ylen) # height color lookup table

col <- colorlut[ y-ylim[1]+1 ] # assign colors to heights for each point

rgl.clear()
rgl.surface(x,z,y,color=col)


## Keywords: 'dynamic'.


