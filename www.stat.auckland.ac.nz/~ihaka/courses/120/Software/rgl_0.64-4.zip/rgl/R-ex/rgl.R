###--- >>> `rgl' <<<----- 3D visualization device system

	## alias	 help(rgl)
	## alias	 help(rgl.open)
	## alias	 help(rgl.close)
	## alias	 help(rgl.cur)
	## alias	 help(rgl.set)
	## alias	 help(rgl.quit)

##___ Examples ___:

example(rgl.surface)

## Keywords: 'dynamic'.


