###--- >>> `rgl.viewpoint' <<<----- setup Viewpoint

	## alias	 help(rgl.viewpoint)

##___ Examples ___:


# animated round trip tour

for(i in 1:360) {
  rgl.viewpoint(i,i/4); 
}


## Keywords: 'dynamic'.


