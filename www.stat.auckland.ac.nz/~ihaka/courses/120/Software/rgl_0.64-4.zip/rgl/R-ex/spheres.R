###--- >>> `rgl.spheres' <<<----- add sphere set shape

	## alias	 help(rgl.spheres)

##___ Examples ___:

rgl.spheres(rnorm(10),rnorm(10),rnorm(10),radius=1,color=rainbow(10))

## Keywords: 'dynamic'.


