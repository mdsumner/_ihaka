###--- >>> `rgl.sprites' <<<----- add sprite set shape

	## alias	 help(rgl.sprites)

##___ Examples ___:

rgl.sprites(rnorm(500),rnorm(500),rnorm(500),color=rainbow(100),lit=F,textype="alpha",texture=system.file("textures/particle.png",package="rgl"),alpha=0.2)

## Keywords: 'dynamic'.


