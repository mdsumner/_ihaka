###--- >>> `rgl.texts' <<<----- add text set shape

	## alias	 help(rgl.texts)

##___ Examples ___:

rgl.texts(rnorm(10)*100,rnorm(10)*100,rnorm(10)*100,text=1:10,justify="center", color=heat.colors(10))

## Keywords: 'dynamic'.


