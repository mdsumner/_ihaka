###--- >>> `rgl.bbox' <<<----- setup Bounding Box decoration

	## alias	 help(rgl.bbox)

##___ Examples ___:

  rgl.bbox(color="#333377", emission="#333377",specular="#3333FF", shinines=5,alpha=0.8)

## Keywords: 'dynamic'.


