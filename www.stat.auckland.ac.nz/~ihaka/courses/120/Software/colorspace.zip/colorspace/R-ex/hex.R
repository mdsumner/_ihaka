### Name: hex
### Title: Convert Colors To Hexadecimal Strings
### Aliases: hex
### Keywords: color

### ** Examples

hsv = HSV(seq(0,360,length=7)[-7], 1, 1)
barplot(rep(1,6), col=hex(hsv))



