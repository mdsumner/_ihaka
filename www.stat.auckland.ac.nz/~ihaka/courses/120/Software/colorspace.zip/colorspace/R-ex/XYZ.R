### Name: XYZ
### Title: Create XYZ Colors
### Aliases: XYZ
### Keywords: color

### ** Examples

## Generate white in XYZ space
white = XYZ(95.047, 100.000, 108.883)



