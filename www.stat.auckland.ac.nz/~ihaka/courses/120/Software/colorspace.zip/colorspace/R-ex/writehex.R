### Name: writehex
### Title: Write Hexadecimal Color Descriptions
### Aliases: writehex
### Keywords: color

### ** Examples

x = RGB(runif(10), runif(10), runif(10))
writehex(x, "random.txt")



