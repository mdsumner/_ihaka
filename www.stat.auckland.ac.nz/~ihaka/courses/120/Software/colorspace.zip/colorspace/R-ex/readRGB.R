### Name: readRGB
### Title: Read RGB Color Descriptions
### Aliases: readRGB
### Keywords: color

### ** Examples

rgb = readRGB("pastel.rgb")
hsv = readRGB("pastel.rgb", "HSV")



