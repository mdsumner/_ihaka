### Name: HSV
### Title: Create HSV Colors
### Aliases: HSV
### Keywords: color

### ** Examples

# A rainbow of full-intensity hues
hsv = HSV(seq(0, 360, length=13)[-13], 1, 1)



