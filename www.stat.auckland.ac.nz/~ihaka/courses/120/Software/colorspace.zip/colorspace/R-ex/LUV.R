### Name: LUV
### Title: Create LUV Colors
### Aliases: LUV
### Keywords: color

### ** Examples

## Show the LUV space
x = RGB(runif(1000), runif(1000), runif(1000))
plot(as(x,"LUV"))



