### Name: hex2RGB
### Title: Convert Hexadecimal Color Specifications To RGB Objects
### Aliases: hex2RGB
### Keywords: color

### ** Examples

rgb = hex2RGB("#FF0000","#00FF00", "#0000FF")



