### Name: polarLAB
### Title: Create polarLAB Colors
### Aliases: polarLAB
### Keywords: color

### ** Examples

## Show the polarLAB space
x = RGB(runif(1000), runif(1000), runif(1000))
plot(as(x,"polarLAB"))



