### Name: RGB
### Title: Create RGB Colors
### Aliases: RGB
### Keywords: color

### ** Examples

# Create a random set of colors
rgb = RGB(R = runif(20), G = runif(20), B = runif(20))



