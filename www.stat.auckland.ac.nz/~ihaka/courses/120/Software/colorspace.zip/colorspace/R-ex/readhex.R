### Name: readhex
### Title: Read Hexadecimal Color Descriptions
### Aliases: readhex
### Keywords: color

### ** Examples

rgb = readhex("pastel.txt")
hsv = readhex("pastel.txt", "HSV")



