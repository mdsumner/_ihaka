### Name: hcl
### Title: Create R Colours from Hue, Chroma and Luminance
### Aliases: hcl
### Keywords: color

### ** Examples

barplot(rep(1, 12), col = hcl(seq(0, 360, length = 13)[1:12]))



