### Name: LAB
### Title: Create LAB Colors
### Aliases: LAB
### Keywords: color

### ** Examples

## Show the LAB space
x = RGB(runif(1000), runif(1000), runif(1000))
plot(as(x,"LAB"))



